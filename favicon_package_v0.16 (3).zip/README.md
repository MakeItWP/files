# Your Favicon Package

This package was generated with [RealFaviconGenerator](https://realfavicongenerator.net/) [v0.16](https://realfavicongenerator.net/change_log#v0.16)

## Install instructions

To install this package:

Extract this package in <code><?php echo https://raw.githubusercontent.com/MakeItWP/Favicons/master/ ?></code>. For example, you should be able to access a file named <code><?php echo https://raw.githubusercontent.com/MakeItWP/Favicons/master/ ?>favicon.ico</code>.

Insert the following code in the `head` section of your pages:

    <link rel="apple-touch-icon" sizes="180x180" href="https://raw.githubusercontent.com/MakeItWP/Favicons/master/apple-touch-icon.png?v=47MvGBErdy">
    <link rel="icon" type="image/png" sizes="32x32" href="https://raw.githubusercontent.com/MakeItWP/Favicons/master/favicon-32x32.png?v=47MvGBErdy">
    <link rel="icon" type="image/png" sizes="16x16" href="https://raw.githubusercontent.com/MakeItWP/Favicons/master/favicon-16x16.png?v=47MvGBErdy">
    <link rel="manifest" href="https://raw.githubusercontent.com/MakeItWP/Favicons/master/site.webmanifest?v=47MvGBErdy">
    <link rel="mask-icon" href="https://raw.githubusercontent.com/MakeItWP/Favicons/master/safari-pinned-tab.svg?v=47MvGBErdy" color="#2ecc71">
    <link rel="shortcut icon" href="https://raw.githubusercontent.com/MakeItWP/Favicons/master/favicon.ico?v=47MvGBErdy">
    <meta name="msapplication-TileColor" content="#2ecc71">
    <meta name="msapplication-config" content="https://raw.githubusercontent.com/MakeItWP/Favicons/master/browserconfig.xml?v=47MvGBErdy">
    <meta name="theme-color" content="#2ecc71">

*Optional* - Check your favicon with the [favicon checker](https://realfavicongenerator.net/favicon_checker)